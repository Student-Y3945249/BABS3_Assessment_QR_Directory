# Modelling Infectious Disease Dynamics to Explore the Effects of 
# Restricting Movement at Different Initial Infection Levels

# Set Up ----------------------------------------------------------------------

library(tidyverse)

# used to extract numbers from strings
library(stringr)

# used to export plots as svg files
library(svglite)

# Read in Data ----------------------------------------------------------------

# set working directory and folder containing all data files

setwd("***REPLACE WITH YOUR WORKING DIRECTORY PATH****")

disease <- read_csv("data-raw/covid19_model_output.csv")

# take a look at the data
str(disease)
view(disease)

# Data Description ------------------------------------------------------------

# 10,113 observations on 9 variables

# movement indicates whether the model is with or without restricted movement 
#   it takes the value "Free Movement" or "Restricted Movement"

# initial_infection indicates the number of people infected with the disease
#   at time (tick) zero, it can take one of the following 10 values:
#   5, 10, 15, 20, 25, 30, 35, 40, 45, 50

# repeat_ID is the run number, it can take any whole number from 1 to 10 
#   as the model has been run 10 times both with and without restricted movement
#   for each of the initial infection levels

# tick is the time, it can take any whole number from 0 to 50
#   as each run was allowed to continued until either the number of people 
#   infected reached zero or time (tick) reached 50

# infected is the number of people infected with the disease, 
#   at time (tick) 0 this is set by initial_infection

# susceptible is the number of people who are not currently infected with
#   the disease but who are at risk of contracting it because they haven't had
#   it before and therefore lack immunity

# immune is the number of people who are no longer susceptible to the 
#   disease because they have had it before and recovered from it,
#   note that this assumes you can't get the disease more than once 
#   in the duration of the run (up to 50 ticks)

# population is the number of people alive, 
#  at time (tick) zero there were 671 people alive in each run

# num_dead is the total number of people who have died

# NOTE that the population can be divided into susceptible, infected and immune
# i.e. population = susceptible + infected + immune,
# and so,     671 = susceptible + infected + immune + num_dead
# hence these variables are correlated and are not independent

# I am particularly interested in the number of people infected with the 
# disease, as these people can transmit the disease to others and will 
# indicate the point at which the health care service becomes overwhelmed

# Produce Scatter Plots and Explore the Data ----------------------------------

# subset the data to look at one run of one scenario

set_repeat_ID <- 1
set_initial_infec <- 20
set_move <- "Free Movement"

disease_R_I_M <- disease %>%
  filter(repeat_ID == set_repeat_ID, 
         initial_infection == set_initial_infec,
         movement == set_move)

# bring all the values into one column to create plot with legend

disease_R_I_M_long <- disease_R_I_M %>% 
  rename(Susceptible = susceptible, Infectious = infected, 
         Recovered = immune, Deceased = num_dead) %>%
  select(movement, initial_infection, repeat_ID, tick, 
         Susceptible, Infectious, Recovered, Deceased) %>%
  pivot_longer(cols = !c(movement, initial_infection, repeat_ID, tick), 
               values_to = "num", names_to = "measure")

view(disease_R_I_M_long)

ggplot(data=disease_R_I_M_long)+ 
  geom_point(aes(x = tick, y = num, group = measure, color = measure)) +
  scale_color_manual(
    values = c(
      "Susceptible" = "#363636",
      "Infectious"  = "#FF4040",
      "Recovered"   = "#1874CD",
      "Deceased"    = "#458B00"
    ),
    breaks = c("Susceptible", "Infectious", "Recovered", "Deceased")
  ) +
  labs(title = paste("Initially Infected = ",
                     set_initial_infec, "out of 671,",  
                     set_move, ", Run = ", set_repeat_ID),
       x = "Tick (Time)", y = "Number of People") +
  scale_y_continuous(limits = c(0, 700)) +
  guides(color = guide_legend(override.aes = list(size = 4))) +
  theme_classic() +
  theme(legend.text = element_text(size=10),
        legend.position = "inside",
        legend.position.inside = c(0.88, 0.50),
        legend.background = element_rect(colour = "#363636"),
        legend.title=element_blank())

# compute the average number people infected against time (tick) across runs
# for each initial infection level and movement regime

disease_av <- disease %>%
  group_by(movement, initial_infection, tick) %>%
  summarise(mean_infected = mean(infected),
            mean_susceptible = mean(susceptible),
            mean_immune =  mean(immune),
            mean_num_dead = mean(num_dead))

view(disease_av)

# subset the data for each movement regime
disease_av_free <- disease_av %>% filter(movement == "Free Movement")
disease_av_restrict <- disease_av %>% filter(movement == "Restricted Movement")

fig1 <- ggplot()+
  geom_line(data = disease_av_free, aes(x = tick, y = mean_infected,
                                        group = initial_infection, 
                                        color = "Free Movement"), 
            linewidth = 1.0) +
  geom_line(data = disease_av_restrict, aes(x = tick, y = mean_infected, 
                                            group = initial_infection, 
                                            color = "Restricted Movement"), 
            linewidth = 1.0) +
  scale_color_manual(values = c("Free Movement" = "#F88179", 
                                "Restricted Movement" = "#22C7CD")) +
  labs(title = "Average Number of People Infected Across Runs",
       subtitle = "For Each Initial Infection Level and Movement Regime",
       x = "Tick (Time)", y = "Average Number of People Infected") +
  scale_y_continuous(limits = c(0, 200), breaks = seq(0, 200, by = 20)) +
  theme_classic() +
  theme(legend.text = element_text(size=10),
        legend.position = "inside",
        legend.position.inside = c(0.80, 0.80),
        legend.background = element_rect(colour = "#363636"),
        legend.title=element_blank())

fig1

ggsave("figures/figure1.svg",
       plot = fig1,
       width = 2125,
       height = 1500,
       units = "px",
       dpi = 300)

# subset the data to look at the number of people infected for each repeat run 
# (and averaged across runs) against time (tick) for one initial infection level
# and both movement regimes

set_initial_infec <- 20

disease_I <- disease %>% filter(initial_infection == set_initial_infec)
disease_av_I <- disease_av %>% filter(initial_infection == set_initial_infec)

fig2 <- ggplot()+
  geom_line(data = disease_I, aes(x = tick, y = infected, 
                                  group = interaction(movement, repeat_ID), 
                                  color = movement))+
  geom_line(data =  disease_av_I, aes(x = tick, y = mean_infected, 
                                      group = movement, colour = movement), 
            linewidth = 1.2) +
  scale_y_continuous(limits=c(0, 200), breaks = seq(0, 200, by = 20)) +
  labs(title = "Number of People Infected for Each Run (and Average Across Runs)",
      subtitle = paste("where Number of People Initially Infected =", 
                       set_initial_infec, "out of 671"), 
       x = "Tick (Time)", y = "Number of People Infected") +
  theme_classic() +
  theme(legend.text = element_text(size=10),
        legend.position = "inside",
        legend.position.inside = c(0.80, 0.80),
        legend.background = element_rect(colour = "#363636"),
        legend.title=element_blank())

fig2

ggsave("figures/figure2.svg",
       plot = fig2,
       width = 2125,
       height = 1500,
       units = "px",
       dpi = 300)

# restricting movement appears to reduce the average number of people infected 
# with the maximum being lower and occurring earlier

# calculate the maximum number of people infected, maximum number of people 
# dead and the maximum time (tick) reached for each run of the model

disease_max <- disease %>%
  group_by(movement, initial_infection, repeat_ID) %>%
  summarise(max_tick = max(tick), 
            max_infected = max(infected), 
            max_dead = max(num_dead))

view(disease_max)

# look at runs which stopped before time (tick) 50
filter(disease_max, max_tick < 50)

# look at the maximum number of people infected both with and without 
# restricted movement for each run of the model

ggplot(data = disease_max) +
  geom_point(aes(x = initial_infection, y = max_infected, 
                 shape = movement, color = movement), 
             position = position_jitter(w = 0, h = 0), size = 2) +
  scale_color_manual(values = c("Free Movement" = "#F88179", 
                                "Restricted Movement" = "#22C7CD")) +
  labs(title = paste("Maximum Number of People Infected (Infection Peak)",
       "vs. Number of People Initially Infected"),
       x = "Number of People Initially Infected", 
       y = "Infection Peak") +
  scale_y_continuous(limits=c(0, 200), breaks = seq(0, 200, by = 20)) +
  theme_classic() +
  theme(legend.text = element_text(size=10),
        legend.position = "inside",
        legend.position.inside = c(0.84, 0.10),
        legend.background = element_rect(colour = "#363636"),
        legend.title = element_blank())

# these data can be analysed using a Generalised Linear Model (GLM),
# response variable: maximum number of people infected (infection peak)
# explanatory variables: 
#   movement (a discrete variable taking the values free or restricted),
#   number of people initially infected (a continuous variable from 5 to 50)

# Fit a Gaussian Identity-Link GLM Model ---------------------------------------

# consider an interaction model to see if the difference between free and 
# restricted movement changes as the number of initial infections increases

disease_max_glm_1<- glm(data = disease_max, 
                         max_infected ~ initial_infection * movement)

summary(disease_max_glm_1)

# or equivalently

disease_max_lm_1 <- lm(data = disease_max, 
                           max_infected ~ initial_infection * movement)

summary(disease_max_lm_1)

# residual deviance 46,408 on 196 degrees of freedom
# AIC 1667

# the main effects of initial infection and movement are highly significant 
# (p < 0.001 and p < 0.001 respectively), however the interaction effect
# is not significant (p = 0.678), 
# this suggests that the effectiveness of restricting movement stays roughly
# the same regardless of how many people are initially infected
# graphically, this means the two lines of dots in the graph are essentially
# parallel, restricted movement provides a consistent reduction as the number 
# of people initially infected increases

# understanding the models coefficients:
# for every additional person initially infected, the infection peak increases
# by about 1.7 people, 
# when starting with the same number of initial infections, restricted 
# movement reduces the peak by roughly 72 people compared to free movement

# look at the model fit

anova(disease_max_glm_1, test = 'Chisq')

# the analysis of deviance confirmed that only the main effect terms 
# contributed significantly to explaining the variance in the data 
# (p < 0.001 and p < 0.001 respectively),
# reduction in residual deviance from 418,337 for null model to 46,449 with 
# inclusion of initial infection and movement terms

# as the interaction term is not significant (p < 0.05) can simplify the model
# by removing the interaction term, making the final estimates for movement and
# initial infection even more precise

disease_max_glm_2 <- glm(data = disease_max, 
                       max_infected ~ initial_infection + movement)

summary(disease_max_glm_2)

# or equivalently

disease_max_lm_2 <- lm(data = disease_max, 
                       max_infected ~ initial_infection + movement)

summary(disease_max_lm_2)

anova(disease_max_glm_2, test = 'Chisq')

# residual deviance 46,449 on 197 degrees of freedom
# AIC 1665.1

# understanding the models coefficients:
# for every additional person initially infected, the infection peak increases
# by about 1.8 people, 
# when starting with the same number of initial infections, restricted 
# movement reduces the peak by roughly 70 people compared to free movement

# Fit a Poisson Log Link GLM Model ---------------------------------------------

# as count data often violate the assumption of normally distributed 
# errors, it may be better to use Poisson (or Negative Binomial) regression

disease_max_pglm <- glm(data = disease_max, 
                         max_infected ~ initial_infection + movement,
                         family = poisson(link = "log"))

summary(disease_max_pglm)

# residual deviance 794.3 on 197 degrees of freedom
# AIC is 2116.8

# in a Poisson model the residual deviance should be roughly equal to the 
# degrees of freedom, in this case the residual deviance (794.3) is almost four
# times the degrees of freedom (197) suggesting that this is not a good fit,
# also the Poisson model has a higher AIC (2056.7) than the Gaussian model 
# (1665.1), which is an indicator that the Gaussian model fits better

min(disease_max$max_infected)
max(disease_max$max_infected)

# even though the maximum number of people infected is a count, the data are
# very large (ranging from 8 to 184) and in this case the Poisson/Negative
# Binomial distribution starts to look very much like a Normal distribution
# and the relationship appears linear rather than exponential

# Overall Conclusion: use the Gaussian Identity Link GLM Model

# Model Predictions ------------------------------------------------------------

# generate a range of initial infection levels both with and without restricted 
# movement for predictions

predicted_disease_max <- data.frame(
  movement = rep(c("Free Movement", "Restricted Movement"), each = 10),
  initial_infection = rep(seq(5, 50, 5), times = 2))

# add predictions

predicted_disease_max <- add_column(predicted_disease_max,
        fit = predict(disease_max_glm_2, 
                        newdata = predicted_disease_max, 
                        type = 'link'))

# add standard errors

predicted_disease_max <- add_column(predicted_disease_max,
  se_fit = predict(disease_max_glm_2, 
                   newdata = predicted_disease_max, 
                   type = 'link', se.fit = TRUE)$se.fit)

# compute 95% confidence interval

qt_value <- qt(0.025, df = df.residual(disease_max_glm_2), lower.tail = FALSE)
predicted_disease_max <- mutate(predicted_disease_max, 
                                lwr_fit = fit - (qt_value * se_fit),
                                upr_fit = fit + (qt_value * se_fit)) 

view(predicted_disease_max)

# or equivalently to check values
conf_intervals <- predict(disease_max_lm_2, 
                          newdata = predicted_disease_max,
                          interval = 'confidence')
view(conf_intervals)

# Model Evaluation -------------------------------------------------------------

# plot the observed and predicted values to see how well the Gaussian GLM model
# matches the data

fig3 <- ggplot() +
  geom_point(data = disease_max, 
             aes(x = initial_infection, y = max_infected, color = movement), 
             size = 2, show.legend = FALSE) +
  geom_line(data = predicted_disease_max,
            aes(x = initial_infection, y = fit, color = movement),
            linewidth = 1.2, show.legend = TRUE) +
  scale_color_manual(values = c("Free Movement" = "#F88179", 
                                "Restricted Movement" = "#22C7CD")) +
  geom_ribbon(data = predicted_disease_max,
              aes(x = initial_infection, group = movement,
                  ymin = lwr_fit, ymax = upr_fit), alpha = 0.2) +
# include this block of code to view the poisson model fit
# geom_smooth(data = disease_max,
#             aes(x = initial_infection, y = max_infected, color = movement), 
#             method = "glm", 
#             method.args = list(family = "poisson"), 
#             SE = TRUE, show.legend = FALSE) +
  scale_y_continuous(limits=c(0, 200), breaks = seq(0, 200, by = 20)) +
  labs(title = "GLM Model Fit with 95% CI",
       subtitle = "Lines Represent the Predicted Peak Infection",
       x = "Number of People Initially Infected",
       y = "Infection Peak") +
  theme_classic() +
  theme(legend.text = element_text(size=10),
        legend.position = "inside",
        legend.position.inside = c(0.82, 0.10),
        legend.background = element_rect(colour = "#363636"),
        legend.title = element_blank())

fig3

ggsave("figures/figure3.svg",
       plot = fig3,
       width = 2125,
       height = 1500,
       units = "px",
       dpi = 300)

# run diagnostic plots to check the residuals are normally distributed

plot(disease_max_glm_2, which=1)
plot(disease_max_glm_2, which=2)

# residuals vs fitted plot: the red line is relatively flat, and the spread of
# points is fairly consistent across the range of predicted values,
# this suggests the Gaussian assumption holds up well 

# Q-Q residuals plot: the points fall mostly along the dashed diagonal line, 
# while there is some tailing off at the very high end, it is minimal,
# suggesting that the residuals are normally distributed

# extract the residuals for Shapiro-Wilk normality test

disease_max_glm_residuals <- residuals(disease_max_glm_2)
shapiro.test(disease_max_glm_residuals)

# Shapiro-Wilk test is not significant (p = 0.6454), suggesting that the
# residuals are normally distributed

# Conclusion: While maximum infection counts are often modelled using a 
# Poisson distribution, diagnostic checks and AIC comparison revealed that a 
# Gaussian GLM provided a significantly better fit (AIC = 1665.1 vs 2056.7), 
# indicating a linear relationship and a non-significant interaction between 
# initial infection size and movement type (p = 0.678)

